public class TransposeMatrix{
public static void(string args[]){
int a[]={{1,3,4},{2,4,3},{3,4,5}};
int transpose[][]=new int[3][3];
for(int i=0;i<3;i++){
for(int j=0;j<3;j++){
transpose[i][j]=original[j][i];
}
}
System.out.print("Printing Matrix without transpose");
for(int i=0;i<3;i++){
for(int j=0;j<3;j++){
System.out.print(original[i][j]+"");
System.out.pritnt();
System.out.print("Printing Matrix with transpose:");
for(int i=0;i<3;i++){
for(int j=0;j<3;j++){
System.out.print(transpose[i][j]+"");
}
System.out.print();
}
}
}
